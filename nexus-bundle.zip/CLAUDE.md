# CLAUDE.md - Briefing for every agent working in this repo

Read this first, every session. It is the shared memory of the team.

## 0. First-run bootstrap
If `nexus-bundle.zip` exists in the repo root:
1. Unzip it into the repo root (keep folder structure, overwrite placeholders).
2. Delete the zip, commit "bootstrap: unpack nexus bundle", push.
3. Trigger these workflows once by hand and report each result to the owner:
   `calm-scan`, `nexus-outcome-tracker`, and `nexus-wallet-scan` (only if the
   `HELIUS_API_KEY` secret exists and `data/wallets/wallets.json` is present).
4. Update `docs/STATUS.md` with what ran, what failed, and what you fixed.

## 1. Mission
Find out - with evidence, not hope - whether any system here can pick Solana
meme coins that beat random picks. **Paper trading only.** Meanwhile the owner's
reliable income path is an online service business; never let this repo eat
that time.

The owner: accounting graduate in Ireland, new to trading, works from a
**phone** (GitHub app + Google Colab). Every instruction you give them must be
**numbered step-by-step**, phone-friendly, no terminal commands.

## 2. The Four (see `.claude/agents/`)
| Agent | Question | Guardrail |
|---|---|---|
| Architect | What is possible? | Max 3 options, must recommend 1 |
| Engine | Can we make it work? | Every test ties to the objective; never invent results |
| Operator | What must happen next? | Cannot finalise before Sentinel speaks |
| Sentinel | What could destroy it? | Top 3 risks, each with mitigation + kill criterion |

For a decision, run them in order: Operator intake -> Architect -> Engine ->
Sentinel -> one clash round -> Operator orders (max 3 actions today).

## 3. Hard rules
1. **No real money** follows any signal until a forward test shows an edge
   (see section 5). No code here may sign transactions or hold a private key.
2. **Secrets only in GitHub Secrets** (`HELIUS_API_KEY`, `RUGCHECK_API_KEY`,
   `SOLANA_RPC_URL`). Never commit a key. If one appears in a diff, stop and tell the owner.
3. **Facts vs hypotheses.** Label estimates. Never report a run as working
   until you have seen it go green. Never fabricate data.
4. **Stdlib Python only** unless there is a strong reason (the runners and Colab stay simple).
5. **Ship before building.** Do not start a new system while an existing one
   is broken or not yet running.
6. Wallet nicknames ("insider", "90% WINRATE", celebrity names) are **unverified
   labels**. Judge wallets only on on-chain behaviour.

## 4. Repo map
| Path | What | Schedule |
|---|---|---|
| `concept_scorer_v1_4.py` | Owner's scorer (v1.4) | used by calm-scan |
| `calm_dashboard.py`, `daily_brief.py` | Scan + dashboard + daily brief | `calm-scan.yml`, hourly :07 |
| `paper_trades.csv`, `shadow_log.csv`, `concept_log_v1_4.csv` | v1.4 paper results | updated by calm-scan |
| `scripts/tracker.py` | Outcome tracker: logs new tokens, prices at +1h/+24h/+7d | `tracker.yml`, hourly :17 |
| `data/tracker/REPORT.md` | Tracker verdict (high tier vs mid+low) | auto |
| `scripts/wallet_scan.py` | Scores wallets from `data/wallets/wallets.json` via Helius | `wallet_scan.yml`, Mon 06:41 + manual |
| `data/wallets/SCORECARD.md` | Wallet labels, top-10 shortlist, clusters | auto |
| `docs/STATUS.md` | Decision log + current state - **update every session** | manual |

Workflows commit back to `main` with `git pull --rebase` retries.

## 5. Success criteria and checkpoints
- **Tracker (day 14 = 2026-10-30):** need 50+ HIGH and 50+ MID+LOW tokens at +24h.
  Edge = HIGH median beats MID+LOW by >= 10 points AND has a lower dead rate.
  No edge -> stop tuning this scorer; reuse the code for the Trading 212 backtest
  and the money-copilot tool.
- **v1.4 paper trades:** if after 100 trades the median net change is still
  below -50%, v1.4 is retired.
- **Wallets:** a wallet is only a CANDIDATE if >= 15 closed trades, win rate
  >= 40%, positive realised PnL, median hold >= 5 min, no single trade > 60% of profit.
  Candidates must then beat dex-discovery tokens in the tracker before they matter.

## 6. Work queue (top = next)
1. Get all three workflows green; fix anything that breaks on live data.
2. Run the wallet scan; publish the shortlist and avoid list.
3. "Wallet watch": hourly, log new buys of the top-10 candidates into the
   tracker with `source=wallet:<name>`, and add a source breakdown to REPORT.md.
4. Feed the avoid list into scoring (penalise tokens held by losing/rugger wallets).
5. Day-14 review on 2026-10-30 with The Four. Decision: continue, pivot or kill.

## 7. How to report to the owner
Short. The Four headers when it's a decision. End with **Today: max 3 numbered
actions**, the first doable in 5 minutes. Always say what is proven vs untested.
