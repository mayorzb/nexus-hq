"""
Nexus Wallet Scan v0.1  (The Four)

Reads  data/wallets/wallets.json   (your wallet-tracker export, pasted as-is)
Pulls  each wallet's recent transactions from Helius (free API key)
Scores every wallet on REAL on-chain behaviour, not on its nickname
Writes data/wallets/scorecard.csv  +  data/wallets/SCORECARD.md

Needs repo secret HELIUS_API_KEY. Read-only: no wallet, no keys of yours, no trading.
Standard library only.
"""

import csv
import json
import os
import statistics
import sys
import time
import urllib.error
import urllib.request
from collections import defaultdict
from itertools import combinations

ROOT = os.path.join(os.path.dirname(__file__), "..", "data", "wallets")
IN_PATH = os.path.join(ROOT, "wallets.json")
CSV_PATH = os.path.join(ROOT, "scorecard.csv")
MD_PATH = os.path.join(ROOT, "SCORECARD.md")

API = "https://api.helius.xyz/v0/addresses/{}/transactions?api-key={}&limit=100"
WSOL = "So11111111111111111111111111111111111111112"
MAX_PAGES = int(os.environ.get("MAX_PAGES", "3"))   # 3 x 100 txs per wallet
COBUY_WINDOW_S = 300                                # bought same token within 5 min
DAY = 86400

# Thresholds (hypotheses - tune after the first run)
MIN_CLOSED = 15        # closed trades needed before we judge a wallet
MIN_WINRATE = 0.40
MIN_HOLD_MIN = 5       # faster than this = you can't realistically copy it
BOT_HOLD_MIN = 2
BOT_SWAPS_DAY = 50
ONE_HIT_SHARE = 0.60   # one trade = >60% of all profit -> luck, not skill
INACTIVE_DAYS = 30


# ---------------------------------------------------------------- fetch
def get_json(url, retries=4):
    req = urllib.request.Request(url, headers={"User-Agent": "nexus-wallet-scan/0.1"})
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(3 * (attempt + 1))
                continue
            if e.code in (401, 403):
                sys.exit("Helius rejected the API key. Check the HELIUS_API_KEY secret.")
            print(f"    HTTP {e.code}")
            return None
        except Exception as e:
            print(f"    {type(e).__name__}: {e}")
            time.sleep(2)
    return None


def fetch_txs(addr, key):
    txs, before = [], None
    for _ in range(MAX_PAGES):
        url = API.format(addr, key) + (f"&before={before}" if before else "")
        page = get_json(url)
        if not isinstance(page, list) or not page:
            break
        txs.extend(page)
        before = page[-1].get("signature")
        time.sleep(0.25)
        if len(page) < 100:
            break
    return txs


# ---------------------------------------------------------------- parse
def swaps_from(addr, txs):
    """Turn raw txs into clean SOL<->token swaps: (ts, mint, qty, sol)."""
    out = []
    for tx in txs:
        if tx.get("transactionError"):
            continue
        sol = 0.0
        for ad in tx.get("accountData") or []:
            if ad.get("account") == addr:
                sol += (ad.get("nativeBalanceChange") or 0) / 1e9
        tok = defaultdict(float)
        for tt in tx.get("tokenTransfers") or []:
            amt = float(tt.get("tokenAmount") or 0)
            if tt.get("toUserAccount") == addr:
                tok[tt.get("mint")] += amt
            if tt.get("fromUserAccount") == addr:
                tok[tt.get("mint")] -= amt
        sol += tok.pop(WSOL, 0.0)
        moved = {m: q for m, q in tok.items() if abs(q) > 1e-9}
        if len(moved) != 1 or abs(sol) < 0.001:
            continue                       # transfer, airdrop, multi-hop: skip
        mint, qty = next(iter(moved.items()))
        if (qty > 0 and sol < 0) or (qty < 0 and sol > 0):
            out.append((int(tx.get("timestamp") or 0), mint, qty, sol))
    return sorted(out)


def score_wallet(addr, swaps, now):
    pos = defaultdict(lambda: {"bq": 0.0, "sq": 0.0, "cost": 0.0, "proc": 0.0,
                               "t_buy": None, "t_sell": None})
    buys = []
    for ts, mint, qty, sol in swaps:
        p = pos[mint]
        if qty > 0:
            p["bq"] += qty
            p["cost"] += -sol
            p["t_buy"] = p["t_buy"] or ts
            buys.append((mint, ts))
        else:
            p["sq"] += -qty
            p["proc"] += sol
            p["t_sell"] = ts
    closed = [p for p in pos.values() if p["bq"] > 0 and p["sq"] >= 0.9 * p["bq"]]
    pnls = [p["proc"] - p["cost"] for p in closed]
    holds = [(p["t_sell"] - p["t_buy"]) / 60 for p in closed if p["t_sell"] and p["t_buy"]]
    wins = [x for x in pnls if x > 0]
    days = {ts // DAY for ts, *_ in swaps}
    m = {
        "swaps": len(swaps),
        "tokens": len(pos),
        "closed": len(closed),
        "win_rate": round(len(wins) / len(closed), 3) if closed else "",
        "pnl_sol": round(sum(pnls), 3) if closed else "",
        "median_trade_sol": round(statistics.median(pnls), 3) if pnls else "",
        "median_hold_min": round(statistics.median(holds), 1) if holds else "",
        "median_buy_sol": round(statistics.median([-s for _, _, q, s in swaps if q > 0]), 3)
                          if any(q > 0 for _, _, q, _ in swaps) else "",
        "swaps_per_day": round(len(swaps) / max(len(days), 1), 1),
        "top_win_share": round(max(wins) / sum(wins), 2) if wins else "",
        "last_trade_days": round((now - swaps[-1][0]) / DAY, 1) if swaps else "",
    }
    m["label"] = label(m)
    return m, buys


def label(m):
    if not m["swaps"] or (m["last_trade_days"] != "" and m["last_trade_days"] > INACTIVE_DAYS):
        return "inactive"
    hold, spd = m["median_hold_min"], m["swaps_per_day"]
    if hold != "" and hold < BOT_HOLD_MIN and spd > BOT_SWAPS_DAY:
        return "bot/sniper (uncopyable)"
    if m["closed"] < MIN_CLOSED:
        return "too few trades"
    if m["top_win_share"] != "" and m["top_win_share"] > ONE_HIT_SHARE and m["pnl_sol"] > 0:
        return "one-hit (luck?)"
    if (m["pnl_sol"] > 0 and m["win_rate"] >= MIN_WINRATE
            and hold != "" and hold >= MIN_HOLD_MIN):
        return "CANDIDATE"
    if m["pnl_sol"] <= 0:
        return "losing"
    return "profitable but hard to copy"


# ---------------------------------------------------------------- clusters
def cobuy_pairs(all_buys):
    """Wallets that keep buying the same token within 5 minutes of each other."""
    by_mint = defaultdict(list)
    for wallet, buys in all_buys.items():
        firsts = {}
        for mint, ts in buys:
            firsts.setdefault(mint, ts)
        for mint, ts in firsts.items():
            by_mint[mint].append((ts, wallet))
    pairs = defaultdict(int)
    for entries in by_mint.values():
        if len(entries) > 60:          # mega-popular token: not a signal
            continue
        for (t1, w1), (t2, w2) in combinations(sorted(entries), 2):
            if w1 != w2 and abs(t2 - t1) <= COBUY_WINDOW_S:
                pairs[tuple(sorted((w1, w2)))] += 1
    return sorted(((n, a, b) for (a, b), n in pairs.items() if n >= 3), reverse=True)


# ---------------------------------------------------------------- main
def main():
    key = os.environ.get("HELIUS_API_KEY")
    if not key:
        sys.exit("Missing HELIUS_API_KEY secret.")
    with open(IN_PATH, encoding="utf-8") as f:
        raw = json.load(f)
    wallets = {}
    for w in raw:
        a = (w.get("trackedWalletAddress") or "").strip()
        if a and a not in wallets:
            wallets[a] = (w.get("name") or "").strip(" ,") or "(unnamed)"
    print(f"{len(wallets)} unique wallets")

    now = int(time.time())
    rows, all_buys = [], {}
    for i, (addr, name) in enumerate(wallets.items(), 1):
        print(f"[{i}/{len(wallets)}] {name}")
        swaps = swaps_from(addr, fetch_txs(addr, key))
        m, buys = score_wallet(addr, swaps, now)
        all_buys[addr] = buys
        rows.append({"name": name, "address": addr, **m})

    os.makedirs(ROOT, exist_ok=True)
    fields = list(rows[0].keys()) if rows else ["name", "address"]
    with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

    write_md(rows, cobuy_pairs(all_buys), wallets)
    print("done")


def write_md(rows, pairs, names):
    def short(a):
        return a[:4] + "..." + a[-4:]

    counts = defaultdict(int)
    for r in rows:
        counts[r["label"]] += 1
    cands = sorted([r for r in rows if r["label"] == "CANDIDATE"],
                   key=lambda r: r["pnl_sol"], reverse=True)
    L = ["# Wallet Scorecard",
         f"Scanned **{len(rows)}** wallets | last ~{MAX_PAGES * 100} transactions each.",
         "Judged on on-chain behaviour only - nicknames are ignored.", "",
         "## Breakdown", "", "| Label | Wallets |", "|---|---|"]
    L += [f"| {k} | {v} |" for k, v in sorted(counts.items(), key=lambda x: -x[1])]
    L += ["", "## Shortlist (top 10 candidates)", "",
          "| # | Name | Wallet | PnL SOL | Win % | Closed | Hold min | Buy SOL |",
          "|---|---|---|---|---|---|---|---|"]
    for i, r in enumerate(cands[:10], 1):
        L.append(f"| {i} | {r['name']} | [{short(r['address'])}]"
                 f"(https://solscan.io/account/{r['address']}) | {r['pnl_sol']} | "
                 f"{r['win_rate'] * 100:.0f}% | {r['closed']} | {r['median_hold_min']} | "
                 f"{r['median_buy_sol']} |")
    if not cands:
        L.append("| - | No wallet passed every check | | | | | | |")
    L += ["", "## Possible clusters (same buys within 5 min, 3+ times)", ""]
    if pairs:
        L += ["| Times | Wallet A | Wallet B |", "|---|---|---|"]
        L += [f"| {n} | {names[a]} | {names[b]} |" for n, a, b in pairs[:20]]
    else:
        L.append("None found.")
    L += ["", "---",
          "_PnL = realised SOL on positions bought AND sold inside the window "
          "(fees included). Past results != future results. Candidates still need the "
          "forward test before any money follows them._"]
    with open(MD_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")


if __name__ == "__main__":
    main()
