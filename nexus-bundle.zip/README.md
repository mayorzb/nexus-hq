# Nexus HQ

Home of The Four (Architect, Engine, Operator, Sentinel) and the Nexus research systems.
Paper trading only - this repo never touches a wallet or real money.

- **Agents:** read `CLAUDE.md` (briefing) and `.claude/agents/` (the four roles).
- **Status:** `docs/STATUS.md`
- **Results:** `dashboard.html`, `brief_latest.md`, `data/tracker/REPORT.md`, `data/wallets/SCORECARD.md`

## Owner setup guide (phone)

### A. Create the repo
1. In your phone's browser go to github.com, tap **+** then **New repository**.
2. Name it `nexus-hq`. Choose **Public** (unlimited free Actions minutes; nothing secret lives in the code). Tick **Add a README**. Tap **Create**.

### B. Upload the bundle
1. In the new repo tap **Add file -> Upload files**.
2. Choose `nexus-bundle.zip` from your phone's Files. Tap **Commit changes**.

### C. Add your secrets
1. **Settings -> Secrets and variables -> Actions -> New repository secret**.
2. Name `HELIUS_API_KEY`, paste your key from helius.dev, **Add secret**.
3. If you used `RUGCHECK_API_KEY` or `SOLANA_RPC_URL` before, add them the same way.

### D. Allow the bots to save results
1. **Settings -> Actions -> General**.
2. Under **Workflow permissions** choose **Read and write permissions**, tap **Save**.

### E. Hand over to the team
1. Start a new Claude task and select the **nexus-hq** repo (give it **write** access when asked).
2. Paste your wallet export JSON into the chat.
3. Send: "Read CLAUDE.md, do the first-run bootstrap, save my wallets to data/wallets/wallets.json, and report back as The Four."

### F. Retire the old repo's bot
1. Once nexus-hq shows green runs, open **nexus-scanner -> Actions -> calm-scan**.
2. Tap **...** then **Disable workflow**.
