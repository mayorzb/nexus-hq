# STATUS - decision log

Newest first. Every agent adds a dated entry when something changes.

## 2026-10-16 - Repo created (moved from nexus-scanner)
**State**
- calm-scan (v1.4): was running hourly in nexus-scanner. Moved here unchanged.
- Outcome tracker (`scripts/tracker.py`): built, tested on simulated data only. Never run live.
- Wallet scanner (`scripts/wallet_scan.py`): built, tested on simulated data only. Needs `HELIUS_API_KEY` + `data/wallets/wallets.json` (owner's 282-wallet tracker export).

**Findings**
- v1.4 paper trades, first ~24h (35 trades, 2026-10-15 15:22 -> 10-16 14:32 UTC): median net change -90.5%, 22 of 35 down 80%+, 2 positive, 0 doubled. Small sample, one market day - strong early warning, not a final verdict.
- No API keys found committed in the old repo (scorer reads them from env vars).
- Wallet list (static review): ~15 "insider" labels, ~14 self-claimed PnL/winrate labels, ~8 dev/test wallets, several repeated families (Noodles x13, omtad x6, el insider x5, TRUMP x5, Orangie x5). All unverified.

**Decisions**
- Paper trading only. No real money until the day-14 review (2026-10-30) shows an edge.
- Time split: ~80% service business, ~20% this repo.
- Old repo nexus-scanner: disable its calm-scan workflow once this repo's calm-scan is green (avoid two bots doing the same job).

**Open questions for the owner**
- Where did the wallet list come from (mentorship, group, self-collected)?
